package com.example.nfcbeam

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

object Proto {
    const val MAX_BYTES = 5 * 1024 * 1024
    const val CHUNK = 240
    val SELECT = byteArrayOf(
        0x00, 0xA4.toByte(), 0x04, 0x00, 0x07,
        0xF0.toByte(), 0x01, 0x02, 0x03, 0x04, 0x05, 0x06
    )
    val OK = byteArrayOf(0x90.toByte(), 0x00)
    val ERR = byteArrayOf(0x6F, 0x00)
}

/** Shared state between the NFC service and the screen. */
object Inbox {
    @Volatile var listening = false
    @Volatile var onProgress: ((Int, Int) -> Unit)? = null
    @Volatile var onDone: ((String, ByteArray) -> Unit)? = null
    @Volatile var onLost: (() -> Unit)? = null

    var active = false
    var total = 0
    var name = ""
    var seq = 0
    var buf = ByteArrayOutputStream()
    var partial = false

    fun reset() {
        active = false; partial = false; total = 0; name = ""; seq = 0
        buf = ByteArrayOutputStream()
    }
}

class BeamService : HostApduService() {
    private val main = Handler(Looper.getMainLooper())

    override fun processCommandApdu(a: ByteArray, extras: Bundle?): ByteArray {
        val sel = Proto.SELECT
        if (a.size >= sel.size && a.copyOfRange(0, sel.size).contentEquals(sel)) {
            return if (Inbox.listening) Proto.OK else Proto.ERR
        }
        if (!Inbox.listening || a.size < 4 || a[0] != 0x80.toByte()) return Proto.ERR

        val lc = if (a.size > 4) a[4].toInt() and 0xFF else 0
        val end = minOf(5 + lc, a.size)
        val body = if (a.size > 5) a.copyOfRange(5, end) else ByteArray(0)

        when (a[1].toInt() and 0xFF) {
            0x10 -> { // START: 4 bytes size + file name
                if (body.size < 4) return Proto.ERR
                val total = ByteBuffer.wrap(body, 0, 4).int
                val name = String(body, 4, body.size - 4, Charsets.UTF_8)
                if (total <= 0 || total > Proto.MAX_BYTES) return Proto.ERR
                if (Inbox.partial && Inbox.total == total && Inbox.name == name) {
                    Inbox.active = true
                    Inbox.partial = false
                    progress(Inbox.buf.size(), total)
                    return Proto.OK
                }
                Inbox.reset()
                Inbox.total = total
                Inbox.name = name
                Inbox.active = true
                progress(0, total)
                return Proto.OK
            }
            0x20 -> { // CHUNK: 2 bytes sequence + data
                if (!Inbox.active || body.size < 3) return Proto.ERR
                val seq = ((body[0].toInt() and 0xFF) shl 8) or (body[1].toInt() and 0xFF)
                if (seq == Inbox.seq - 1) return Proto.OK // retransmit
                if (seq != Inbox.seq) return Proto.ERR
                Inbox.buf.write(body, 2, body.size - 2)
                Inbox.seq++
                if (Inbox.seq % 10 == 0) progress(Inbox.buf.size(), Inbox.total)
                return Proto.OK
            }
            0x40 -> { // RESUME: sender continues from this byte offset
                if (!Inbox.active || body.size < 4) return Proto.ERR
                val off = ByteBuffer.wrap(body, 0, 4).int
                if (off != Inbox.buf.size() || off % Proto.CHUNK != 0) return Proto.ERR
                Inbox.seq = off / Proto.CHUNK
                return Proto.OK
            }
            0x30 -> { // END
                if (!Inbox.active || Inbox.buf.size() != Inbox.total) return Proto.ERR
                val data = Inbox.buf.toByteArray()
                val name = Inbox.name
                Inbox.reset()
                Inbox.listening = false
                val cb = Inbox.onDone
                main.post { cb?.invoke(name, data) }
                return Proto.OK
            }
        }
        return Proto.ERR
    }

    private fun progress(got: Int, total: Int) {
        val cb = Inbox.onProgress
        main.post { cb?.invoke(got, total) }
    }

    override fun onDeactivated(reason: Int) {
        if (Inbox.active) {
            Inbox.active = false
            Inbox.partial = true
            val cb = Inbox.onLost
            main.post { cb?.invoke() }
        }
    }
}
